import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class FastCollinearPoints {
    private final ArrayList<LineSegment> lines = new ArrayList<>();

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("The array is null.");

        for (Point p : points)
            if (p == null)
                throw new IllegalArgumentException("The array contains null element.");

        Point[] copy = points.clone();
        Arrays.sort(copy);
        for (int i = 0; i < copy.length - 1; i++)
            if (copy[i].compareTo(copy[i + 1]) == 0)
                throw new IllegalArgumentException("Duplicate found.");

        for (int i = 0; i < points.length - 1; i++) {
            Arrays.sort(copy);
            Arrays.sort(copy, copy[i].slopeOrder());
            ArrayList<Double> slopes = new ArrayList<>();
            for (int j = i + 1; j < copy.length; j++)
                slopes.add(copy[i].slopeTo(copy[j]));

            for (int k = 0, m = 1, n = 2; n < slopes.size(); k++, m++, n++) {
                if (slopes.get(k).equals(slopes.get(m)) && slopes.get(m).equals(slopes.get(n))) {
                    ArrayList<Point> pts = new ArrayList<>();
                    pts.add(copy[k + 1]);
                    pts.add(copy[m + 1]);
                    pts.add(copy[n + 1]);
                    pts.add(copy[i]);
                    Collections.sort(pts);
                    lines.add(new LineSegment(pts.get(0), pts.get(3)));
                }
            }
        }
    }


    // the number of line segments
    public int numberOfSegments() {
        return lines.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return lines.toArray(new LineSegment[0]);
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
